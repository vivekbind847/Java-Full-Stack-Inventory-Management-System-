package com.crud.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crud.model.Product;
/*@Repository-it is used to access data object
 * used to storage and reterive data
 * 
 * */
@Repository
public interface ProductRepository extends JpaRepository<Product,Long> {

}
