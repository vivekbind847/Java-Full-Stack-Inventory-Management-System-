package com.crud.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.crud.model.User;
@Repository
public interface UserRepository extends JpaRepository<User,Long> {
	/*
	 * Optional<T>-having 
	 * isPresent()
	 * if data is available then it will return true otherwise false
	 * OrElse()
	 * if value is available it will return otherwise it will return null
	 * */
	Optional<User> findByUsernameAndPassword(String username, String password);
}
