package com.crud.service;

import java.util.List;

import com.crud.model.Product;

public interface ProductService {

	public Product createProduct(Product p);
	public List<Product>getAllProduct();
	public Product getProductById(Long id);
	public Product updateProduct(Product p);
	public void deleteProductById(Long id);
}
