package com.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*@SpringBootApplication-marks class is having main method 
 * it is combination of 3 annotations
 * -@EnableAutoConfiguartion-Automatically loads all jar files
 * -@Configuration-Configure all bean methods
 * -@ComponentScan-scan all base packages
 * 
 * 
 * */
@SpringBootApplication
public class InventorySystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorySystemApplication.class, args);
	}

}
