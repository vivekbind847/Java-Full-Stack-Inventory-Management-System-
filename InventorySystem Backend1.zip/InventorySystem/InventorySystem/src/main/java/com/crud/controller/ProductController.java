package com.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.exception.ProductNotFoundException;
import com.crud.model.Product;
import com.crud.service.ProductServiceImp;
/*@RestController  is combination of
 * 
 * @Controller and @ ResponseBody
 * 
 * */
@RestController
//@RequestMapping it handle web request
@RequestMapping("/api/product")
@CrossOrigin("*")

public class ProductController {

	@Autowired
	ProductServiceImp service;

	@PostMapping
	public ResponseEntity<Product>createProduct(@RequestBody  Product p){
		Product pp=service.createProduct(p);
		return new ResponseEntity<Product>(pp,HttpStatus.OK);
	}
	@GetMapping
	
	public ResponseEntity <List<Product>>getAllProduct(){
		List<Product>list= service.getAllProduct();
		return new ResponseEntity<List<Product>>(list,HttpStatus.ACCEPTED);
	

	}

	@GetMapping("/{id}")
	
	public ResponseEntity<Product> getProductById(@PathVariable ("id")Long id )
	
	throws ProductNotFoundException{
		Product e=service.getProductById(id);
		return new ResponseEntity<Product>(e,HttpStatus.OK);
		
	}
	@PutMapping("/{id}")
	public ResponseEntity<Product> update(@RequestBody Product e, @PathVariable("id") Long id) {
	   e.setId(id);
		service.updateProduct(e);
	   return new ResponseEntity<>(service.getProductById(id), HttpStatus.OK);
	   
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Product> deleteProductById(@PathVariable("id") Long id)
			throws ProductNotFoundException{
		
		service.deleteProductById(id);
		 return new ResponseEntity<Product>(HttpStatus.OK);
	}
	
	
}
