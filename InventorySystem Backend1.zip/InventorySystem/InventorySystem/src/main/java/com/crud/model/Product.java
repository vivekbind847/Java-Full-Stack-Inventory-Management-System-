package com.crud.model;

import jakarta.persistence.*;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Data
@NoArgsConstructor
@Entity
@Table(name="productInfo")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="pid")
	
	 private Long id;
	@Column(name="pname")
	 @NotBlank(message = "Name is mandatory")
	 private String name;
	@Column(name="pdesc")
	 @NotBlank(message = "Name is mandatory")
	 private String description;
	@Column(name="pprice")
	 @NotNull
	 private double price;
	 
	 public Product(String name, String description, double price) {
	        this.name = name;
	        this.description = description;
	        this.price = price;
	    }
}
